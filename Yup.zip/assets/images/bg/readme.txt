the name of the bg is the name of the folder
contents of the folder is just 'frame[x].png'
if there is only 1 frame, just name it 'frame1.png'
There is also an optional file called "config.txt" which can let you add different things
Just note, if you use config.txt, you need every value there