**MADE BY ANDREW CHURCH**
**THIS IS THE PSEUDOCODE FOR THE GAME**
**MADE IN FULL**
**SO I CAN TRY OUT MY GAY ASS ABILITIES**
**WITH PROGRAMMING**

Universal settings dictionary, read from a file, first thing loaded

Preloading
-text values
-images
-sound LOCATIONS

Menus
-a spawned box that displays the preloaded text
-if the text is not preloaded it will load the text for future use
-UI can *overlay* meu
-This should be its own separate project

